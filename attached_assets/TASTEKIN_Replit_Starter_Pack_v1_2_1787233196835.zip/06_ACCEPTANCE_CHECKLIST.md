# TASTEKIN — Phase 1 Acceptance Checklist

## Product

- [ ] New consumer can sign up/login and finish Taste onboarding.
- [ ] Home, Explore, Saved and You navigation works.
- [ ] Demo creator profile matches the canonical no-follower-count reference.
- [ ] Admin-granted verification badge is visible.
- [ ] Taste Match opens an explanation of the score.
- [ ] Public and locked Edits appear in the same feed.
- [ ] Locked Edit does not expose subscriber media to a non-subscriber.
- [ ] Mock subscription changes access state and can be reset for testing.
- [ ] Collections and Collection detail work.
- [ ] Save/unsave and follow/unfollow persist after refresh.
- [ ] Creator can draft, preview, publish and archive an Edit.
- [ ] Creator dashboard loads realistic demo metrics.
- [ ] Admin can invite, verify/revoke and resolve a report.

## Visual

- [ ] Uses supplied logo and Oxblood palette.
- [ ] No follower count in default public profile.
- [ ] Demo price is `$19.99/month`.
- [ ] Mobile viewport is polished at 390x844.
- [ ] Desktop does not break or stretch content excessively.
- [ ] Loading, empty, error and unavailable states exist.

## Technical

- [ ] Database persists core data across restart/refresh.
- [ ] Authorization is enforced on the backend.
- [ ] Media uses object storage abstraction.
- [ ] No secrets are committed to source code.
- [ ] No production payments are enabled.
- [ ] Seed script or deterministic demo dataset is included.
- [ ] README explains run, test and deploy steps.
- [ ] Critical flows are tested in Preview before publishing.

