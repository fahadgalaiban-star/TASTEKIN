# TASTEKIN Replit Starter Pack

This package provides product requirements and visual references for planning and building the TASTEKIN MVP with Replit Agent.

## Start

1. Import the ZIP into Replit or upload these files to a new Replit app.
2. Enable Plan mode.
3. Paste the full contents of `01_REPLIT_MASTER_PROMPT_EN.txt`.
4. Review and approve the plan before any code is written.

## Package contents

- `00_START_HERE_AR.md` — Arabic instructions for the owner
- `01_REPLIT_MASTER_PROMPT_EN.txt` — first prompt for Replit Agent
- `02_PRODUCT_REQUIREMENTS_MVP.md` — product scope
- `03_USER_FLOWS.md` — critical journeys
- `04_DATA_MODEL_AND_RULES.md` — suggested entities and security rules
- `05_DESIGN_SYSTEM.md` — brand and interface direction
- `06_ACCEPTANCE_CHECKLIST.md` — definition of done
- `replit.md` — persistent Agent project context
- `assets/ui` — canonical and supporting UI references
- `assets/brand` — logo and icon assets
- `reference` — compact brand guide

The latest canonical profile is `assets/ui/01_profile_no_followers.png`.

