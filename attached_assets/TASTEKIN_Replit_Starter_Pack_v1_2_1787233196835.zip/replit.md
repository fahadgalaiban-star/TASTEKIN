# TASTEKIN Agent Context

Read `01_REPLIT_MASTER_PROMPT_EN.txt` and all numbered specification files before changing code or data.

## Project rules

- Plan first; build only after the user approves the plan.
- Mobile-first Web App/PWA, primary viewport 390x844.
- TypeScript throughout unless the approved plan explains otherwise.
- Keep UI, domain logic, persistence, authorization and payment adapters separate.
- Use environment variables/Secrets; never commit credentials.
- Use integer cents for money.
- Enforce subscriber access and creator ownership on the backend.
- Provide seeded demo data and reproducible setup.
- Preserve the canonical no-follower-count profile and TASTEKIN brand system.
- Do not add out-of-scope features without approval.

## Current demo decisions

- Creator: Fheed Alaiban
- Subscription: $19.99/month, creator-configurable
- Demo split: 80% creator / 20% TASTEKIN before external costs
- Follower count: hidden by default
- Verification: admin-controlled only
- Payments: mock/test only in Phase 1

