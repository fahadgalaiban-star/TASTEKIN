# TASTEKIN — Design System

## Brand character

Premium editorial lifestyle, calm confidence, warm minimalism, curated rather than crowded.

## Colors

- Oxblood: `#4B1F2A` — primary actions, active states and verification
- Burnt Coral: `#E85F42` — locks, subscriber accents and selected highlights
- Deep Ink: `#171416` — main text
- Warm Ivory: `#F5F1E9` — primary background
- Soft Stone: `#B8B0A5` — secondary text/details
- Sage functional tint: `#DCE9E3` — Taste Match background only
- Sage ink: `#2F6F61` — Taste Match text only

Do not use green as a primary brand color. Do not introduce a blue primary palette.

## Typography

- Editorial serif for creator names and feature titles.
- Clean sans serif for navigation, metadata, buttons and body copy.
- Keep body text accessible and avoid very light gray text.

## Layout

- Mobile-first primary viewport `390x844`.
- Generous spacing and rounded cards.
- Bottom navigation with five destinations.
- One clear primary action per state.
- Locked content uses tasteful blur plus explicit label; never rely on blur alone for authorization.

## Canonical creator header

Use `assets/ui/01_profile_no_followers.png` as the current reference.

- No public follower count by default.
- Verification badge beside the display name.
- Show username and creator categories.
- Show Edits and Collections counts.
- Taste Match is prominent but secondary to identity.
- Follow is outline; Subscribe is solid Oxblood with Coral lock.
- Demo Subscribe label: `$19.99/month`.

## Accessibility

- Minimum 44x44px tap targets.
- Visible focus states.
- Semantic buttons/links.
- Alt text for meaningful images.
- Do not communicate locked/public state through color alone.

