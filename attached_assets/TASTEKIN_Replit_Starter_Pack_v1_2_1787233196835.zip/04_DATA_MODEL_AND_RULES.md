# TASTEKIN — Data Model and Business Rules

## Suggested entities

- `users`: id, email, username, display_name, avatar_url, role, status, created_at
- `creator_profiles`: user_id, bio, categories, city, verification_status, follower_count_visibility, subscription_enabled, monthly_price_cents
- `taste_profiles`: user_id, categories, styles, colors, brands, cities, content_types, updated_at
- `follows`: follower_user_id, creator_user_id, created_at
- `edits`: id, creator_id, title, caption, content_type, access_level, status, sponsored, published_at
- `edit_media`: id, edit_id, media_type, storage_url, position, alt_text
- `collections`: id, creator_id, title, description, cover_url, access_level, status
- `collection_items`: collection_id, edit_id, position
- `saves`: user_id, saveable_type, saveable_id, created_at
- `places`: id, name, city, country, coordinates, website_url
- `products`: id, name, brand, image_url, destination_url, affiliate_disclosure
- `edit_places`: edit_id, place_id
- `edit_products`: edit_id, product_id, position
- `subscriptions`: id, subscriber_id, creator_id, provider, provider_ref, status, price_cents, current_period_end
- `subscription_events`: subscription_id, event_type, amount_cents, metadata, created_at
- `reports`: reporter_id, target_type, target_id, reason, notes, status, reviewed_by
- `admin_actions`: admin_id, action, target_type, target_id, reason, created_at
- `analytics_events`: user_id, creator_id, edit_id, event_name, created_at

## Permissions

- Consumers can edit only their own profile, follows and saves.
- Creators can manage only their own Edits, Collections and subscription settings.
- Admin-only actions: verification, suspension, moderation and audit review.
- Subscriber-only media must be authorized server-side. UI blur alone is not security.
- Never expose original private media URLs to a non-subscriber.

## Taste Match

- Calculate on the server or trusted backend logic.
- Store score cache with version and calculated timestamp.
- Return score plus human-readable reasons.
- Recalculate after meaningful Taste Profile or behavior changes.

## Payments

- Prices stored as integer minor units, never floating point.
- Payment provider is abstracted.
- Webhooks/events are idempotent.
- Access is derived from verified subscription status, never from a client-side flag.
- Phase 1 uses fake/test events only.

## Privacy and moderation

- Minimum required profile data only.
- Report/block/mute options.
- Soft-delete content before permanent deletion.
- Log sensitive admin actions.

