# TASTEKIN — User Flows

## Consumer discovery

Open app → onboarding/login → Home → open Creator → inspect Taste Match → view public Edit → Follow or Save.

## Subscription preview

Open locked Edit → blurred preview → Subscribers Only explanation → view creator subscription benefits → test checkout → active subscription state → unlock Edit.

## Explore

Explore → enter query or filter → results grouped by Creators / Edits / Collections / Places → open item → follow, save or subscribe.

## Collection

Creator profile → Collections → open Collection → see public and locked items → open available Edit or subscription preview.

## Creator publishing

Creator owner profile → Add → choose content type → upload media → write title/caption → attach place/product/links → select Public or Subscribers Only → preview → publish.

## Creator subscription setup

Creator settings → Subscription → choose approved monthly price → describe benefits and posting expectation → submit/publish → subscription button appears.

## Admin verification

Admin → Creators → open creator review → inspect identity/content signals → approve verification with internal note → audit log entry → badge appears publicly.

## Report handling

User opens profile/Edit options → Report → select reason → submit → Admin queue → resolve, warn, remove or dismiss → audit log.

