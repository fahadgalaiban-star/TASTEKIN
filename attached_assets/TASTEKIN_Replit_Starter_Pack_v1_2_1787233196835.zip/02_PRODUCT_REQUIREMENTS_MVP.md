# TASTEKIN — MVP Product Requirements

## Product promise

Discover people, places, products and routines through compatible taste—not popularity.

## Primary users

1. **Consumer** — browses, follows, saves, builds a Taste Profile and may subscribe.
2. **Creator** — invitation-based at launch; publishes Edits and Collections and may offer a paid subscription.
3. **Admin** — invites and verifies creators, moderates reports and controls platform quality.

Brands and self-serve storefronts are out of scope for MVP.

## Core navigation

- Home
- Explore
- Add (creator only; consumer sees an invitation/info state)
- Saved
- You

## Core screens

### 1. Authentication and onboarding

- Email/social login interface.
- Select interests: Style, Travel, Fitness, Places, Fragrance, Food and more.
- Select preferred styles, colors, brands, cities and content types.
- Save answers as structured Taste Profile data.

### 2. Home

- Mixed feed of followed and recommended creators.
- Public and locked Edits can appear in the same feed.
- Clear labels: Public Edit, Subscribers Only, Sponsored.
- Save, share, open creator, open place/product.

### 3. Explore

- Search creators, Edits, Collections, places and products.
- Filters by category, city and content type.
- Creator cards prioritize Taste Match, not follower count.

### 4. Creator profile

Canonical order:

1. Avatar
2. Display name + admin-granted verification badge
3. Username
4. Categories
5. `Edits · Collections` counts
6. Taste Match + Why you match
7. Follow and Subscribe actions
8. Tabs: Edits, Collections, About

Follower count is hidden by default. Do not include it in the canonical profile screen.

### 5. Edits

Supported MVP formats:

- Photo
- Carousel
- Short video metadata/player placeholder
- Shoppable look
- Place guide
- Workout/routine
- Product list
- Travel guide

Access states:

- Public
- Subscribers Only
- Sponsored
- Unavailable/deleted

### 6. Collections

- A named ordered group of Edits.
- Access: public, subscribers-only or mixed.
- Show title, description, cover, item count and last updated date.

### 7. Subscription

- Creator-set monthly price from approved price points.
- Demo creator: `$19.99/month`.
- Preview explains what is included before checkout.
- Subscription states: none, active, cancelling at period end, expired, payment issue.
- Phase 1 uses mock/test checkout only.
- Demo economics: 80% creator / 20% TASTEKIN before external fees, taxes, refunds and chargebacks.

### 8. Taste Match

MVP score is deterministic and explainable. Suggested weights:

- Categories: 25%
- Styles/aesthetics: 20%
- Brands/products: 15%
- Cities/places: 15%
- Colors: 10%
- Saved-content behavior: 15%

Show the strongest matching reasons. Never imply scientific or psychological certainty.

### 9. Creator tools

- Owner profile view
- Create/edit/publish/archive an Edit
- Create and reorder Collections
- Set subscription price and description
- Basic dashboard: views, saves, profile visits, subscription count, estimated gross and estimated creator share

### 10. Admin

- Invite creator
- Approve/revoke verification
- Review reports
- Suspend content/account
- View an audit log of admin actions

## Explicitly out of scope

- Direct messages
- Livestreaming
- Stories
- Multiple paid tiers
- Marketplace checkout for physical goods
- Automated creator payouts
- Production payment processing
- AI recommendation model
- Native iOS/Android store submission

